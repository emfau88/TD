# Spire — Hüter des Waldes

Ein vollständiges Tower-Defense-Spiel mit den vorhandenen Foozle-Spire-Assets.

## Spielen

- **Ohne Installation:** `SPIEL STARTEN.cmd` doppelklicken oder `Spire.html` in einem aktuellen Browser öffnen. Alle Grafiken und der Spielcode sind eingebettet; Internet und ein Server sind dafür nicht nötig.
- **Lokale Browser-Version:** `npm run preview` starten und die im Terminal angegebene Adresse öffnen (standardmäßig `http://127.0.0.1:5175/`).
- **Entwicklung:** `npm ci`, danach `npm run dev`.

Die erzeugte `Spire.html` wird mit `npm run build` aktualisiert. `dist/` enthält die normale statische Website und kann mit einem beliebigen Webserver bereitgestellt werden.

## Spielablauf

Wähle eine der drei Karten und baue Türme auf freien Wiesen neben dem Weg. Wellen werden manuell oder automatisch gestartet. Bodengegner folgen den Wegen; Fluggegner nutzen eigene Routen. Jeder besiegte Gegner bringt Gold, jede überstandene Welle einen Bonus.

Türme greifen automatisch an. Ein Klick auf einen gebauten Turm öffnet Aufwertungen, Zielprioritäten und Verkauf. Jeder Turm hat drei Stufen; Verkauf erstattet 70 % des investierten Goldes. Überstehe 20 Wellen, bevor die 20 Spire-Leben aufgebraucht sind. Jede fünfte Welle enthält einen besonders starken Gegner.

| Turm | Rolle |
| --- | --- |
| Waldwächter | Günstige Pfeile gegen Boden und Luft |
| Frostkristall | Verlangsamung |
| Steinschleuder | Flächenschaden gegen Bodengegner |
| Scharfschütze | Große Reichweite, ignoriert Rüstung |
| Sturmlicht | Kettenblitze |
| Schnellfeuer | Schnelle Salven gegen Boden und Luft |
| Glutwerfer | Brandschaden gegen Bodengegner |
| Sonnenobelisk | Schwerer magischer Flächenschaden |

## Steuerung

| Eingabe | Aktion |
| --- | --- |
| Maus / Touch | Turm wählen, platzieren oder auswählen |
| 1–8 | Turmtyp wählen |
| Escape / rechte Maustaste | Bauauswahl abbrechen |
| Leertaste | Pause / Fortsetzen |
| N | Nächste Welle starten |
| U | Ausgewählten Turm aufwerten |
| F | Geschwindigkeit zwischen 1× und 2× wechseln |

Die Kartenauswahl pausiert die laufende Verteidigung und bietet „Laufendes Spiel fortsetzen“. Sterne, beste Welle, Einführung und Audioeinstellungen werden lokal im Browser gespeichert. Drei Sterne erfordern mindestens 18 verbleibende Leben, zwei Sterne mindestens 10. Ein laufendes Gefecht wird beim Schließen oder Neuladen beendet. Die Offline-Datei und die Server-Version können getrennte Browser-Speicher verwenden.

## Prüfung und Build

```text
npm test
npm run test:ui
npm run balance:sim
npm run build
npm run test:package
```

Die Simulationstests prüfen Bauplätze, Gold, Upgrades, Verkauf, Zielprioritäten, Rüstung, Brand, Frost, Kettenblitz, Flugrouten, Niederlage und Sieg. Die Kampagnenprüfung spielt alle drei Karten mit regulärem Startgold und einer reproduzierbaren Bau- und Aufwertungsstrategie durch.

Die UI-Prüfung führt Menü, Einführung, Bau-/Turmverwaltung, Pause, Geschwindigkeit, Ergebnis und gespeicherte Werte in einer simulierten DOM-Umgebung aus. Sie ersetzt keine visuelle Prüfung der Phaser-Darstellung im Browser.

## Projektstruktur

- `src/data.ts`: Karten, Turm- und Gegnerwerte, Wellen.
- `src/simulation.ts`: Spiellogik, unabhängig von der Darstellung.
- `src/scene.ts`: Phaser-Szene, Landschaft, Animationen und Effekte.
- `src/main.ts`: Menüs und Bedienung.
- `src/audio.ts`: Lokal erzeugte Spieleffekte.
- `src/assets.ts`: Asset-Laden für Server und Offline-Datei.
- `scripts/prepare-assets.py`: PNGs kopieren und Aseprite-Metadaten auslesen.
- `scripts/package-offline.mjs`: Build und Grafiken in `Spire.html` einbetten.

Die Original-Assetordner sind erhalten. Zum erneuten Vorbereiten der Assets: `python scripts/prepare-assets.py`, anschließend `npm run build`. Node.js 22 oder neuer wird für die Entwicklungswerkzeuge verwendet.

## Assets

Die Oberfläche verwendet sieben eigens erzeugte Pixelart-PNGs aus `public/ui/`: Fensterrahmen, Button-Zustände, Waldkulisse, Spire-Emblem, HUD-Symbole, Turmkarten und Kartenillustrationen. Eine lokale Übersicht liegt unter `/ui/catalog.html`. Atlas-Aufteilung und Maße stehen in `public/ui/manifest.json`, die vollständigen Imagegen-Prompts in `public/ui/README.md`. `src/ui-skin.css` setzt die Bilder ein; Texte, Goldwerte und Tastenbeschriftungen bleiben HTML. Das Offline-Paket bettet auch diese Grafiken ein.

Die acht mitgelieferten Foozle-Pakete stammen von Foozle und Baldur. Ihre jeweiligen `Readme.txt` nennen CC0. Die Grafiken werden aus den PNG-Exports geladen; echte Aseprite-Framegrößen, Richtungen und Animationszeiten werden berücksichtigt. Soundeffekte werden im Spiel erzeugt, es werden keine externen Sound- oder Schriftdateien benötigt.
